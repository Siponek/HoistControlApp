#!/bin/bash
echo "Reasons for why our group is that much late are simple:"
echo "I (Szymon) work full time at Danieli Automation as a Software developer engineer"
echo "and"
echo "Maciej works full time as international product engineer in American company in Germany."

echo "Also moving to Genova from Poland was not an easy task."





echo "Unmoutn&mount for fifo when using Ubuntu WSL:"
echo "sudo umount /mnt/c "
echo "sudo mount -t drvfs C: /mnt/c -o metadata"